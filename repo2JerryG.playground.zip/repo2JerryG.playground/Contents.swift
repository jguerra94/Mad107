import UIKit

// Variables and Constants
let appName = "Pizza Dash"
let resturantName = "Little Italy Pizzeria"
let pizzaType1 = "Thin Crust"
let pizzaType2 = "Deep Dish"
let pizzaType3 = "Brooklyn & New York Style"
let small14inthinCrust = 18.99
let large18inthinCrust = 24.99
let small14indeepDish = 22.99
let large18indeepDish = 28.99
let small14inNyc = 18.99
let large18inNyc = 24.99
let pepporoniTop1 = 1.00
let stuffedcheeseTop2 = 4.00
let extracheeseTop3 = 1.25
let sausageTop4 = 1.00
let olivesTop5  = 0.50
let bananapeppersTop6  = 0.50
let bbqchickenTop7 = 2.25
let baconbitsTop8 = 1.75
let order = "A large Deep Dish with extra cheese, pepporoni, stuffed cheese and bacon bits"
let taxAmnt = 0.08
let deliveryFee = 2.50
let tip = 4.00

// Operator calculations
var totalCost = large18indeepDish + extracheeseTop3 + pepporoniTop1 + stuffedcheeseTop2 + baconbitsTop8 + deliveryFee
var tax = totalCost * taxAmnt
var costafterTax = 3.15 + totalCost
var finalPrice = costafterTax + tip

// Print Results
print("Hello thanks for downloading Pizza Dash!")
print("You have selected to order pizza from", resturantName)
print("Your order is", order)
print("Your total cost before tax is", totalCost)
print("Your cost after tax is", costafterTax)
print("Thank you for tipping your driver", tip)
print("Your final price with taxes and fees including tip is", finalPrice)
print("Estimated time for delivery is 1 hour. Thanks and we hope to serve you again soon!")



