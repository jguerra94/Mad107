class Car {
    var name: String = "Prius"
    var model: String = ""
    var year: Int = 2024
    
    func drive() {
        print("Driving the \(name)")
    }
    
    enum priusColor {
        case red
        case blue
        case silver
        case charcoalGray
        case black
        case white
    }
    // make an enum for prius models
    enum priusModel {
        case LE
        case XLE
        case Limited
        case LEAwd
        case XLEAwd
        case LimitedAwd
    }
    // struct user package options
    struct priusPackage {
        var sunroof: Bool
        var premiumSoundSystem: Bool
        var leatherSeats: Bool
        var backupCamera: Bool
        var gps: Bool
        var parkingAssist: Bool
    }

    var color: priusColor
    var modelType: priusModel
    var package: priusPackage
    
    init(color: priusColor, modelType: priusModel, package: priusPackage) {
        self.color = color
        self.modelType = modelType
        self.package = package
    }
    
    func printPriusConfiguration() {
        print("Year: \(year), Color: \(color), Model: \(modelType)")
        print("Package Configuration:")
        print("Sunroof: \(package.sunroof ? "Yes" : "No")")
        print("Premium Sound System: \(package.premiumSoundSystem ? "Yes" : "No")")
        print("Leather Seats: \(package.leatherSeats ? "Yes" : "No")")
        print("Backup Camera: \(package.backupCamera ? "Yes" : "No")")
        print("GPS: \(package.gps ? "Yes" : "No")")
        print("Parking Assist: \(package.parkingAssist ? "Yes" : "No")")
        print()
    }
}

// Example usage
let prius = Car(color: .blue, modelType: .XLE, package: Car.priusPackage(sunroof: true, premiumSoundSystem: true, leatherSeats: false, backupCamera: true, gps: true, parkingAssist: false))
prius.year = 2024
prius.printPriusConfiguration() // call back function to print the configuration of the prius build
prius.drive()// call back the function to drive the prius
