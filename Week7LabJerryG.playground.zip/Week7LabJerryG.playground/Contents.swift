import UIKit
// create the function
func fibo(_ n: Int) -> [Int] {
    var sequence = [0, 1]
    // for loop that iterates over sequence
    for i in 2..<n {
        sequence.append(sequence[i - 1] + sequence[i - 2])
    }
    //return that sequence
    return sequence
}

// Example usage:
let fibSequence = fibo(18) // Generate first 18 Fibonacci numbers
print(fibSequence)
// print results 
