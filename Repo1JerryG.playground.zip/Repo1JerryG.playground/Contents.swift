import UIKit
// Variables and constants
let appName = "My Budget App"
let job = "iOS Mobile Developer"
let annualSalary = 80400
let monthlyIncome = 6700
let Rent = 1300
let carPayment = 479
let electric = 150
let heating = 100
let water = 50

var clothes = 200
var food = 300
var cellphone = 25
var xfinityTV = 70
var Internet = 100
var gymMembership = 24.99
var netflix = 9.99
var amazonPrime = 14.99
var Entertainment = 800
var investments = 1500
var totalExpenses = 0
var savings = 0



// calculations

totalExpenses = Rent + carPayment + electric + heating + water + clothes + food + cellphone + Int(xfinityTV) + Int(Internet) + Int(gymMembership) + Int(netflix) + Int(amazonPrime) + Int(investments) + Int(Entertainment)
savings = monthlyIncome - totalExpenses


// App feedback result print statements

print("Welcome to \(appName)!")
print("Your current profession is \(job)")
print("Your annual net income is $\(annualSalary).")
print("Your monthly take home net income is $\(monthlyIncome).")
print((totalExpenses), "is the amount you spend on expenses.")
print(savings, "is the amount you save every month.")
print("You have a good budget! For more budgeting tips visit our website!")


















