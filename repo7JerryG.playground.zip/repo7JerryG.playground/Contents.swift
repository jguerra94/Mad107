import UIKit
// check two true fals and one integer
var fitData: (Bool, Bool, Int)?

func fitBitWatchResults() {
    let userSteps = getUserSteps()
    getUserBurnedCals { burnedCalsGoalMet in
        let userSleep = getUserSleep()
        fitData = (userSteps, burnedCalsGoalMet, userSleep)
        print(fitData)
    }
}
// get user steps
func getUserSteps() -> Bool {
    let steps = 2500
    // set up if statement
    if steps >= 2500 {
        print("Steps goal met")
        return true
    } else {
        print("Steps goal not met")
        return false
    }
}
// get user calories burned. (Closure added to this function allowing it to to be called outside this section. Void, voids out the "return" and replaces it with completion true or false.
func getUserBurnedCals(completion: @escaping (Bool) -> Void) {
    let activity1 = "Bicycling"
    var timeOfAct1 = 2 // hours
    var act1BPH = 150 // Calories burned per hour
    let activity2 = "Jogging"
    var timeOfAct2 = 1// hour
    var act2BPH = 250
    let burnedCalsGoal = 400
    
    let calsBurned = timeOfAct1 * act1BPH + timeOfAct2 * act2BPH
    // check to see if calories goal was met
    if calsBurned >= burnedCalsGoal {
        print("Burned calories goal met")
        completion(true)
    } else {
        print("Cals Goal not met")
        completion(false)
    }
}

func getUserSleep() -> Int {
    let hoursSlept = 7
    // check if the integer returned = the same as the sleep goal.
    if hoursSlept >= 7 {
        print("Sleep goal was met")
        return hoursSlept
    } else {
        print("Sleep goal was not met")
        return hoursSlept
    }
}

fitBitWatchResults()
