import UIKit

enum BurgerType {
    case classicCheeseburger
    case baconBurger
    case veggieBurger
    case meltedNachoCheeseburger
}

// Define an enumeration for burger toppings
enum BurgerTopping: String {
    case lettuce
    case tomato
    case onion
    case pickles
    case ketchup
    case mustard
    case mayo
    case extraCheese
    case bacon
    case guac
    case picoDeGallo
    
    // Calculate the price for extra toppings
    func extraToppingPrice() -> Double {
        return 0.25
    }
}

// Define an enumeration for burger cook settings
enum CookSetting: String {
    case wellDone = "Well Done"
    case mediumRare = "Medium Rare"
    case rare = "Rare"
}

// Define a structure for the burger order
struct BurgerOrder {
    var type: BurgerType
    var quantity: Int
    var toppings: [BurgerTopping] // Array of toppings
    var cookSetting: CookSetting
    
    // Calculate the total price of the burger order
    func calculateTotalPrice() -> Double {
        var basePrice = 0.0
        switch type {
        case .classicCheeseburger:
            basePrice = 5.99
        case .baconBurger:
            basePrice = 8.99
        case .veggieBurger:
            basePrice = 5.99
        case .meltedNachoCheeseburger:
            basePrice = 12.99
        }
        
        let extraToppingsPrice = Double(max(0, toppings.count - 4)) * BurgerTopping.lettuce.extraToppingPrice()
        let totalPrice = basePrice + extraToppingsPrice
        return totalPrice * Double (quantity)
    }
}

// Sample usage:

// Create a classic cheeseburger order with extra toppings and cook setting
let classicCheeseburgerOrder = BurgerOrder(type: .classicCheeseburger, quantity: 1, toppings: [.tomato, .onion, .extraCheese, .ketchup, .mustard], cookSetting: .mediumRare)

// Create a bacon burger order with extra toppings and cook setting
let baconBurgerOrder = BurgerOrder(type: .baconBurger, quantity: 1, toppings: [.lettuce, .tomato, .bacon, .extraCheese, .ketchup], cookSetting: .wellDone)

// Create a veggie burger order with extra toppings and cook setting
let veggieBurgerOrder = BurgerOrder(type: .veggieBurger, quantity: 1, toppings: [.lettuce, .tomato, .onion, .pickles], cookSetting: .rare)

// Create a melted nacho cheeseburger order with extra toppings and cook setting
let meltedNachoCheeseburgerOrder = BurgerOrder(type: .meltedNachoCheeseburger, quantity: 1, toppings: [.extraCheese, .guac, .picoDeGallo], cookSetting: .mediumRare)

// Calculate total price for each order
let classicCheeseburgerPrice = classicCheeseburgerOrder.calculateTotalPrice()
let baconBurgerPrice = baconBurgerOrder.calculateTotalPrice()
let veggieBurgerPrice = veggieBurgerOrder.calculateTotalPrice()
let meltedNachoCheeseburgerPrice = meltedNachoCheeseburgerOrder.calculateTotalPrice()

// Print total price for each order
print("Total price for Classic Cheeseburger: $\(classicCheeseburgerPrice)")
print("Total price for Bacon Burger: $\(baconBurgerPrice)")
print("Total price for Veggie Burger: $\(veggieBurgerPrice)")
print("Total price for Melted Nacho Cheeseburger: $\(meltedNachoCheeseburgerPrice)")
