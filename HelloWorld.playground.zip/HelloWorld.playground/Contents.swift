import UIKit

var str = "Hello, playground!"
print("Hello, world!")
