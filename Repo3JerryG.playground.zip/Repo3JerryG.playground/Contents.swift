import UIKit

var hours = 0
var minutes = 0
var seconds = 0


// Loop to continuously update and display the time
while hours < 24 {
    // Display the current time in Central Time Zone
    print("Current Time in Central Time Zone:")
    print(String(format: "%02d:%02d:%02d", hours, minutes, seconds))
    
   // add seconds
    seconds += 1
    
   
    
    if seconds == 60 {
        seconds = 0
        minutes += 1
    }
    
    // Increment hours if minutes reach 60
    if minutes == 60 {
        minutes = 0
        hours += 1
    }
    
    // Reset time at midnight
    if hours == 24 {
        hours = 0
        minutes = 0
        seconds = 0
    }
    
   
    
    usleep(1000000)
}
