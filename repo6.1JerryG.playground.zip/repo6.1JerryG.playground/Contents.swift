import UIKit
// initialize variables
var musicGenre = "Rock and Heavy Metal"
// Create a dictionary for favorite rock and heavy metal bands
var favoriteBandsinOrder = [1:"Coldplay", 2: "Linkin Park", 3:"Metallica", 4:"The Beatles", 5:"Queen", 6:"Def Leppard", 7:"Led Zeppelin", 8:"Nirvana", 9:"U2", 10:"Red Hot Chilli Peppers", 11: "Disturbed"]
// dictionary for total number of albums for each band
var totalAlbums = [1: 9, 2: 7, 3: 11, 4: 12, 5: 15, 6: 12, 7: 8, 9: 15, 10: 13, 11: 8]
// dictionary for band members of each band
var bandMembers = [1: "Chris Martin, Guy Berryman, Will Champion, Jonny Buckland",  2: "Mike Shinoda, Joe Hahn, Rob Bourdon, Dave Farrell, Brad Delson, Scott Koziol. Chester Bennington- Deceased", 3: "James Hetfield, Kirk Hammett, Lars Ulrich, Cliff Burton, Dave Mustaine, Jason Newsted, Ron McGovney", 4: "John Lennon- Deceased, Paul McCartney, George Harrison- Deceased, Ringo Starr", 5: "Freddie Mercury, Brian May, John Deacon, and Roger Taylor.", 6: "Joe Elliott, Phill Collen, Steve Clark, Rick Savage, Tony, Kenning, Pete Willis", 7:"Robert Plant, Jimmy Page, John Bonham, John Paul Jones", 8: "Krist Novoselic, Dave Grohl, Kurt Cobain- Deceased", 9: "Bono, Adam Clayton, Larry Mullen Jr", 10: "Anthony Kiedis, Michael Balzary, Jack Irons", 11: "David Draiman, John Moyer, Mike Wengren, Dan Donegan"]
// Create a dictionary that stores origin of band
var bandCountry = [1: "United Kingdom", 2: "USA", 3: "USA", 4: "United Kingdom", 5: "United Kingdom", 6: "United Kingdom", 7: "United Kingdom", 8: "USA", 9: "United Kingdom", 10: "USA", 11: "USA"]

// create an array of favorite songs in order of band key values.
var favoriteSongs = ["Clocks- Coldplay", "Viva La Vida- Coldplay", "New Divide- Linkin Park", "What I've Done- Linkin Park", "Enter Sandman- Metallica", "Master of Puppetts- Metallica", "Yellow Submarine- The Beatles", "Yesterday- The Beatles", "We Will Rock You- Queen", "Bohemian Rhapsody- Queen", "Animal- Def Leppard", "Photograph- Def Leppard", "Stairway to Heaven- Led Zeppelin", "Good Times Bad Times- Led Zeppelin", "Smells Like Teen Spirit- Nirvana", "Lithium- Nirvana", "With or Without You- U2", "Beautiful Day- U2", "Snow- Red Hot Chilli Peppers", "Californication- Red Hot Chilli Peppers", "Down with the Sickness- Disturbed", "The Sound of Silence- Disturbed"]
// Sort bands by country
let sortedBandsByCountry = bandCountry.sorted { $0.value < $1.value }

// Iterate through sorted bands
for (bandID, country) in sortedBandsByCountry {
    // Get band details
    if let bandName = favoriteBandsinOrder[bandID],
       let albums = totalAlbums[bandID],
       let members = bandMembers[bandID] {
           
        // Print band name
        print("\(bandName):")
        
        // Print band country
        print("Band Country: \(country)")
        
        // Print band members
        print("Band Members: \(members)")
        
        // Print total albums
        print("Total Albums: \(albums)")
        
        // Print favorite songs related to the band
        print("Favorite Songs:")
        for song in favoriteSongs {
            if song.contains(bandName) {
                let songName = song.replacingOccurrences(of: "\(bandName)- ", with: "")
                print("- \(songName)")
            }
        }
        // Separate each band's information
        print("\n")
    }
}
