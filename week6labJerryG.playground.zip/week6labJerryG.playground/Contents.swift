import UIKit

// Initialize current roster data for 2024 season
var teamName = "Chicago Blackhawks"
let currentYear = 2024

// Player count
var playerCount = 29

// Dictionary containing jersey numbers and player names
var jerseyNumber = [
    15: "Joey Anderson", 89: "Andreas Athanasiou", 91: "Anthony Beauviller", 98: "Connor Bedaard",
    43: "Jason Dickinson", 8: "Ryan Donato", 58: "MacKenzie Entwistle", 17: "Nick Foligno",
    70: "Cole Guttman", 71: "Taylor Hall", 52: "Reese Johnson", 90: "Tyler Johnson",
    14: "Boris Katchouk", 23: "Philipp, Kurashev", 39: "Luke Philip", 11: "Taylor Raddysh",
    13: "Zachary Sanford", 46: "Louis Crevier", 4: "Seth Jones", 55: "Kevin Korchinski",
    24: "Jacob Megna", 5: "Connor Murphy", 41: "Isaak Phillips", 72: "Alex Vlasic",
    22: "Nikita Zaitsev", 34: "Peter Mirazek", 40: "Arvid Soderblom"
]

// Dictionary containing player birthdays
var playerBday = [
    15: (month: "06", day: 19, year: 1998), 89: (month: "08", day: 06, year: 1994),
    91: (month: "06", day: 08, year: 1997), 98: (month: "07", day: 17, year: 2005),
    43: (month: "03", day: 28, year: 1993), 8: (month: "04", day: 09, year: 1996),
    58: (month: "07", day: 14, year: 1999), 17: (month: "10", day: 31, year: 1987),
    70: (month: "04", day: 06, year: 1999), 71: (month: "11", day: 14, year: 1991),
    52: (month: "07", day: 10, year: 1998), 90: (month: "07", day: 29, year: 1990),
    14: (month: "06", day: 18, year: 1998), 23: (month: "10", day: 12, year: 1999),
    39: (month: "11", day: 06, year: 1995), 11: (month: "02", day: 18, year: 1998),
    13: (month: "11", day: 09, year: 1994), 46: (month: "05", day: 04, year: 2001),
    24: (month: "12", day: 10, year: 1992), 25: (month: "02", day: 20, year: 1992),
    72: (month: "06", day: 05, year: 2001), 4: (month: "10", day: 03, year: 1994),
    5: (month: "03", day: 26, year: 1993), 41: (month: "09", day: 28, year: 2001),
    22: (month: "10", day: 29, year: 1991), 55: (month: "06", day: 21, year: 2004),
    34: (month: "02", day: 14, year: 1992), 40: (month: "08", day: 19, year: 1999)
]

// Dictionary containing player heights (measured in inches)
var playerHeight = [
    15: 72, 89: 74, 91: 71, 98: 70, 43: 69, 8: 72, 58: 75, 17: 72, 70: 69, 71: 73,
    52: 73, 90: 68, 14: 74, 23: 72, 39: 70, 11: 75, 13: 76, 46: 80, 24: 78, 25: 78,
    72: 78, 4: 76, 5: 76, 41: 75, 22: 74, 55: 73, 34: 74, 40: 75
]

// Dictionary containing player countries
var playerCountry: [Int: String] = [
    15: "USA", 89: "Canada", 91: "Canada", 98: "Canada", 43: "USA", 16: "Canada",
    8: "Canada", 58: "Canada", 17: "USA", 70: "USA", 71: "Canada", 52: "Canada",
    90: "USA", 14: "Canada", 23: "Czech Republic", 39: "Canada", 11: "Canada",
    13: "USA", 46: "Canada", 24: "USA", 25: "USA", 72: "USA", 4: "USA", 5: "USA",
    41: "Canada", 22: "Russia", 55: "Canada", 34: "Czech Republic", 40: "Canada"
]

// Dictionary to store players by country
var playersByCountry: [String: [String]] = [:]

// Populate playersByCountry dictionary
for (number, name) in jerseyNumber {
    if let country = playerCountry[number] {
        if var players = playersByCountry[country] {
            players.append(name)
            playersByCountry[country] = players
        } else {
            playersByCountry[country] = [name]
        }
    }
}

// Iterate over players sorted by country and print them with birthdate and jersey number
for (country, players) in playersByCountry {
    print("Players from \(country):")
    for player in players.sorted() {
        // Find the jersey number for the current player
        if let jerseyNumber = jerseyNumber.first(where: { $0.value == player })?.key,
           let bday = playerBday[jerseyNumber] {
            // Format the birthdate
            let birthdate = "\(bday.month)/\(bday.day)/\(bday.year)"
            // Print player's name, birthdate, and jersey number
            print("- \(player) (Birthdate: \(birthdate), Jersey Number: \(jerseyNumber))")
        }
    }
}


// find average age of player
var totalAge = 0
for (_, birthday) in playerBday {
    let age = currentYear - birthday.year
    totalAge += age
}

let averageAge = totalAge / playerCount
print("Average age of players: \(averageAge)")


// find average height of player
var totalHeight = 0
for (_, height) in playerHeight {
    totalHeight += height
    
}
let averageHeight = totalHeight / playerCount
print("Average height of players in inches,: \(averageHeight)")

