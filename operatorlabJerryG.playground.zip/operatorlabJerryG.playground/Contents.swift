import UIKit

// Variables and Constants
var num0 = 0
var num1 = 1
var num2 = 2
var num3 = 3
var num4 = 4
var num5 = 5
var num6 = 6
var num7 = 7
var num8 = 8
var num9 = 9
var num10 = 10

// Calculations
var sum = 10 + 5
var difference = 10 - 5
var product = 10 * 5
var quotient = 10 / 5

//Results
print("10 + 5 =", sum)
print("10 - 5 =", difference)
print("10 * 5 =", product)
print("10 / 5 =", quotient)



